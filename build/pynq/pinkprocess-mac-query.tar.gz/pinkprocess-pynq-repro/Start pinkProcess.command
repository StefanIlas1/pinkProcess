#!/bin/zsh
set -eu
cd -- "$(dirname "$0")"
exec python3 -m lm_reference.operator_web --software \
  --source inputs/run.c --model inputs/stories260K.ppq \
  --tokenizer inputs/tok512.bin --patch inputs/tim.patch.json "$@"
